# File "Audio.txt" is an Audio Settings File. Use it to increase and decrease Volume.

It's an number from [-80] to [20]. Default value is 0.